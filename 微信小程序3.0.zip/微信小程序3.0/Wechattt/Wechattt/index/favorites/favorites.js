Page({
  data: {
    apiBaseUrl: 'https://ingrid-unencroached-unhumanly.ngrok-free.dev',
    favoriteList: [],
    openid: '',
    isLoading: true
  },

  onLoad() {
    const openid = wx.getStorageSync('openid');
    console.log('收藏页面 onLoad - openid:', openid);
    this.setData({ openid });
  },

  onShow() {
    console.log('收藏页面 onShow');
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().updateSelected('/index/favorites/favorites');
    }
    
    this.loadFavorites();
  },

  loadFavorites() {
    const that = this;
    const openid = wx.getStorageSync('openid') || this.data.openid;
    
    console.log('开始加载收藏列表，openid:', openid);
    
    if (!openid) {
      console.error('错误：openid为空');
      wx.showToast({ 
        title: '请先登录', 
        icon: 'none',
        duration: 2000
      });
      this.setData({ isLoading: false });
      return;
    }

    this.setData({ 
      isLoading: true,
      openid: openid 
    });
    
    // ✅ 修复：将 openid 作为查询参数拼接到 URL 中
    const requestUrl = `${that.data.apiBaseUrl}/api/get_favorites?openid=${encodeURIComponent(openid)}`;
    console.log('完整请求URL:', requestUrl);
    
    wx.request({
      url: requestUrl,
      method: 'GET',
      // ✅ 删除 data 参数，因为 GET 请求不会自动转换
      success(res) {
        console.log('=== 完整的响应对象 ===');
        console.log('状态码:', res.statusCode);
        console.log('响应头:', res.header);
        console.log('响应数据:', res.data);
        console.log('数据类型:', typeof res.data);
        console.log('=== 响应结束 ===');
        
        that.setData({ isLoading: false });
        
        // 更严格的响应检查
        if (res.statusCode === 200 && res.data) {
          if (res.data.status === 'success') {
            const favorites = res.data.favorites || [];
            console.log('成功加载收藏数量:', favorites.length);
            that.setData({ 
              favoriteList: favorites
            });
            
            if (favorites.length === 0) {
              wx.showToast({
                title: '暂无收藏歌曲',
                icon: 'none',
                duration: 2000
              });
            }
          } else {
            // 如果 status 不是 success，检查 msg 字段
            const errorMsg = res.data.msg || '未知错误';
            console.error('收藏列表加载失败，错误信息:', errorMsg);
            wx.showToast({ 
              title: `加载失败: ${errorMsg}`, 
              icon: 'none',
              duration: 3000
            });
          }
        } else {
          console.error('响应状态码异常或数据为空');
          wx.showToast({ 
            title: `服务器响应异常: ${res.statusCode}`, 
            icon: 'none',
            duration: 3000
          });
        }
      },
      fail(err) {
        console.error('网络请求失败详情:', err);
        that.setData({ isLoading: false });
        wx.showToast({ 
          title: '网络错误: ' + (err.errMsg || '未知错误'), 
          icon: 'none',
          duration: 3000
        });
      }
    });
  },

  onRemoveFavorite(e) {
    const music = e.currentTarget.dataset.music;
    const that = this;

    wx.showModal({
      title: '取消收藏',
      content: `确定取消收藏 "${music.music_name}" 吗？`,
      success(res) {
        if (res.confirm) {
          wx.request({
            url: `${that.data.apiBaseUrl}/api/remove_favorite`,
            method: 'POST',
            header: { 'Content-Type': 'application/json' },
            data: {
              openid: that.data.openid,
              music_id: music.music_id
            },
            success(res) {
              if (res.data && res.data.status === 'success') {
                wx.showToast({ 
                  title: '已取消收藏', 
                  icon: 'success',
                  duration: 2000
                });
                that.setData({
                  favoriteList: that.data.favoriteList.filter(item => item.music_id !== music.music_id)
                });
              } else {
                const errorMsg = res.data ? res.data.msg : '操作失败';
                wx.showToast({ 
                  title: errorMsg, 
                  icon: 'none',
                  duration: 2000
                });
              }
            },
            fail(err) {
              console.error('取消收藏失败', err);
              wx.showToast({ 
                title: '网络错误', 
                icon: 'none',
                duration: 2000
              });
            }
          });
        }
      }
    });
  },

  playMusic(e) {
    const song = e.currentTarget.dataset.song;
    console.log('播放收藏歌曲:', song);
    wx.navigateTo({
      url: `/pages/runing/runing?MusicId=${song.music_id}&MusicName=${encodeURIComponent(song.music_name)}&MusicAuthor=${encodeURIComponent(song.music_author || '未知作者')}`
    });
  },

  onRefresh() {
    console.log('手动刷新收藏列表');
    this.loadFavorites();
  }
});